const subjects={
"financial-accounting":{name:"Financial Accounting",desc:"Accounting concepts, practical problems and exam-oriented revision.",articles:[["FA Basics & Journal Entries","Learn the foundation of accounting with simple examples.","house-property"],["Final Accounts","Practice common final-account adjustments.","pyq-tax"]]},
"law-ethics":{name:"Law & Ethics",desc:"Concepts, provisions and quick revision material.",articles:[["Important Law Concepts","Build your chapter-wise conceptual base.","study-plan"]]},
"direct-tax":{name:"Direct Taxation",desc:"Tax concepts, practical questions and PYQ-focused revision.",articles:[["Income from House Property","Easy notes and practical approach.","house-property"],["Direct Tax PYQ Practice","Practice exam-oriented questions.","pyq-tax"]]},
"indirect-tax":{name:"Indirect Taxation",desc:"GST concepts and practical questions.",articles:[["GST Basics","Understand supply, time and value of supply.","pyq-tax"]]},
"cost-accounting":{name:"Cost Accounting",desc:"Cost concepts, formulas and practical problems.",articles:[["Cost Sheet","Learn the structure and common adjustments.","pyq-tax"]]},
"financial-management":{name:"Financial Management",desc:"Formulas, concepts and numerical practice.",articles:[["FM Formula Revision","Quick revision of key formulas.","study-plan"]]}
};
const articles={
"house-property":{title:"Income from House Property — Easy Notes",tag:"DIRECT TAX",subject:"direct-tax",html:`<p>Use this page as a simple revision guide. Add your detailed CMA Inter notes here.</p><div class="note">💡 Exam Tip: Learn the computation format first, then practice adjustments and practical questions.</div><h2>1. Basic Structure</h2><p>Gross Annual Value → Net Annual Value → deductions → Income from House Property.</p><h2>2. What to Practice</h2><ul><li>Self-occupied property questions</li><li>Let-out property computation</li><li>Municipal taxes and interest-related adjustments</li><li>Mixed practical questions</li></ul><h2>3. Revision Method</h2><p>Read the concept, solve one basic question, then attempt a PYQ without looking at the solution.</p>`},
"pyq-tax":{title:"CMA Inter Tax — PYQ Practice Guide",tag:"PYQs",subject:"direct-tax",html:`<p>Use this article as your PYQ practice page. Replace the sample questions below with your verified PYQs.</p><div class="note">⚠️ Always verify the latest syllabus, amendments and official question papers before publishing exam-specific claims.</div><h2>Practice Checklist</h2><ul><li>Chapter-wise PYQs</li><li>Repeated concepts</li><li>Practical computation questions</li><li>Time-bound practice</li></ul><h2>Smart Practice</h2><p>Attempt the question first, mark the time taken, then compare your answer with the official/verified solution.</p>`},
"study-plan":{title:"CMA Inter 60-Day Study Plan",tag:"STUDY PLAN",subject:"financial-accounting",html:`<p>A sample framework for planning your preparation. Adjust the allocation according to your syllabus and personal progress.</p><h2>Days 1–20</h2><p>Build concepts and complete high-priority chapters.</p><h2>Days 21–40</h2><p>Practice chapter-wise questions and PYQs.</p><h2>Days 41–50</h2><p>Revision + timed practice.</p><h2>Days 51–60</h2><p>Mock tests, weak-area revision and final revision.</p>`}
};
function qs(s){return document.querySelector(s)}
function init(){
 const saved=localStorage.getItem("cmaTheme");if(saved==="dark")document.body.classList.add("dark");
 qs("#themeBtn")?.addEventListener("click",()=>{document.body.classList.toggle("dark");localStorage.setItem("cmaTheme",document.body.classList.contains("dark")?"dark":"light")});
 qs(".menuBtn")?.addEventListener("click",()=>qs("nav")?.classList.toggle("open"));
 qs("#searchBtn")?.addEventListener("click",()=>qs("#searchBox")?.classList.toggle("show"));
 const input=qs("#searchInput");input?.addEventListener("input",()=>search(input.value));
}
function search(q){
 const box=qs("#searchResults");if(!box)return; q=q.toLowerCase().trim(); if(!q){box.innerHTML="";return}
 const all=[...Object.entries(articles).map(([id,a])=>({title:a.title,url:`article.html?id=${id}`})),...Object.entries(subjects).map(([id,s])=>({title:s.name,url:`subject.html?subject=${id}`}))];
 const found=all.filter(x=>x.title.toLowerCase().includes(q)).slice(0,8);
 box.innerHTML=found.length?found.map(x=>`<a class="result" href="${x.url}">${x.title}</a>`).join(""):"<div class='result'>No results found.</div>";
}
function renderSubjects(){
 const grid=qs("#subjectGrid");if(!grid)return;
 grid.innerHTML=Object.entries(subjects).map(([id,s])=>`<a class="subjectItem" href="subject.html?subject=${id}"><h2>${s.name}</h2><p>${s.desc}</p><b>Open Subject →</b></a>`).join("");
}
function renderSubjectPage(){
 const id=new URLSearchParams(location.search).get("subject")||"direct-tax",s=subjects[id]||subjects["direct-tax"];
 qs("#subjectTitle").textContent=s.name;qs("#subjectDesc").textContent=s.desc;
 qs("#articleGrid").innerHTML=s.articles.map(a=>`<article class="articleCard"><h2>${a[0]}</h2><p>${a[1]}</p><a class="read-more" href="article.html?id=${a[2]}">Read Article →</a></article>`).join("");
}
function renderArticle(){
 const id=new URLSearchParams(location.search).get("id")||"house-property",a=articles[id]||articles["house-property"];
 qs("#articleContent").innerHTML=`<article class="articleContent"><span class="badge">${a.tag}</span><h1>${a.title}</h1><p><small>CMA Study Hub • Exam-focused learning</small></p>${a.html}<div class="share"><b>Share:</b> <a href="https://wa.me/?text=${encodeURIComponent(a.title+" - CMA Study Hub")}" target="_blank">WhatsApp</a> · <a href="https://t.me/share/url?url=${encodeURIComponent(location.href)}&text=${encodeURIComponent(a.title)}" target="_blank">Telegram</a></div></article>`;
}
init();
function addFloat(){if(document.querySelector(".float"))return;document.body.insertAdjacentHTML("beforeend",`<div class="float"><a class="wa" href="https://wa.me/919999999999" target="_blank" aria-label="WhatsApp">WA</a><a class="tg" href="https://t.me/yourchannel" target="_blank" aria-label="Telegram">TG</a></div>`)}
addFloat();